# Video Downloader API

## API Endpoint:
GET /download?url=VIDEO_URL&format=mp4

## উদাহরণ:
https://your-render-url.onrender.com/download?url=https://www.youtube.com/watch?v=abc123&format=mp4

### ফরম্যাট অপশন:
- mp4 (ভিডিও সহ)
- mp3 (শুধু অডিও)

### ডিপ্লয় পদ্ধতি:
1. GitHub এ কোড আপলোড করো
2. Render.com এ লগইন করে New Web Service তৈরি করো
3. `npm install` এবং `npm start` সেট করো
4. ডিপ্লয় করে API URL ব্যবহার করো
